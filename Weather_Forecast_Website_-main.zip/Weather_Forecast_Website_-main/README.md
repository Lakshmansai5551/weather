# Weather_Forecast_Website_
**Weather_Forecast_Website_**
simple web application to check the current weather state
**API KEY**
To make sure the web app works properly you should use your own API KEY in the script.js file.
This web app is using the openweathermap API.
js/script  
apiKey="YOUR_API_KEY_HERE"
